﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CourseViewPage : ContentPage
    {
        private readonly Course _course;

        public CourseViewPage(Course course)
        {
            _course = course;
            InitializeComponent();

            CourseIdLabel.Text = _course.Id.ToString();
            CourseTitleLabel.Text = _course.Title;
            CourseCreditsLabel.Text = _course.Credits.ToString();
            CourseDepartmentLabel.Text = _course.Department;
        }

        private async void DeleteCourseButton_OnClicked(object sender, EventArgs e)
        {
            bool isDeleteConfirmed = await this.DisplayAlert("Warning!", "Are you sure, you want to delete?", "Yes", "Cancel");

            if (isDeleteConfirmed) 
            { 
                // 1. Check if there is previously saved data
                var dataFilePath = Path.Combine(FileSystem.CacheDirectory, "CourseListData.json");
                List<Course> courseList = new List<Course>();
                if (File.Exists(dataFilePath))
                {
                    // i. Yes, previously saved data exists
                    // ii. Then load the previously saved data into a list
                    var currentDataJson = File.ReadAllText(dataFilePath);
                    courseList = JsonConvert.DeserializeObject<List<Course>>(currentDataJson);
                }
                else
                {
                    // i. Nope, no previously saved data exists
                    return;
                }

                // 2. Delete the selected Course object from the list by looking it up using C# LINQ query
                var isRemoveSuccess =  courseList.Remove(courseList.First(x => x.Id == _course.Id));
                // 3. Check if item was successfully removed
                if (isRemoveSuccess)
                {
                    // i. Yes, successfully removed
                    // ii. Then save the updated list of Courses
                    var courseListJson = JsonConvert.SerializeObject(courseList);
                    File.WriteAllText(dataFilePath, courseListJson);

                    // iii. Navigate back to the previous Page
                    await this.Navigation.PopAsync();
                }

                // 3. Delete failed stay in the current page
            }
            else
            {
                // Delete operation cancelled by User
            }
        }

        private async void GoToEditCourseButton_OnClicked(object sender, EventArgs e)
        {
            await this.Navigation.PushAsync(new CourseEditPage(_course));
        }
    }
}