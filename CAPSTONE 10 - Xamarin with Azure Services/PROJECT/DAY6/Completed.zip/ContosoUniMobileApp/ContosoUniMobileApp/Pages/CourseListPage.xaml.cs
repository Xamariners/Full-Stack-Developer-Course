﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CourseListPage : ContentPage
    {
        public CourseListPage()
        {
            InitializeComponent();
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            string dataFilePath = Path.Combine(FileSystem.CacheDirectory, "CourseListData.json");
            List<Course> courseList = new List<Course>();
            if (File.Exists(dataFilePath))
            {
                string currentDataJson = File.ReadAllText(dataFilePath);
                courseList = JsonConvert.DeserializeObject<List<Course>>(currentDataJson);
            }

            CourseListCollectionView.ItemsSource = courseList;
        }

        private async void AddNewCourseButton_Clicked(object sender, EventArgs e)
        {
            await this.Navigation.PushAsync(new CourseCreatePage());
        }

        private void CourseListCollectionView_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Course selectedCourse = (Course) e.CurrentSelection.First();
            this.Navigation.PushAsync(new CourseViewPage(selectedCourse));
        }
    }
}