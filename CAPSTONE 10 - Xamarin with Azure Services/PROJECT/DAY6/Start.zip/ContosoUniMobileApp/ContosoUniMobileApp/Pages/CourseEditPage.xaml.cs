﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CourseEditPage : ContentPage
    {
        public CourseEditPage(Course course)
        {
            InitializeComponent();

            CourseIdEntry.Text = course.Id.ToString();
            CourseTitleEntry.Text = course.Title;
            CourseCreditsSlider.Value = course.Credits;
            CourseDepartmentEntry.Text = course.Department;
        }

        private async void UpdateCourseButton_Clicked(object sender, EventArgs e)
        {
            string courseIdValue = CourseIdEntry.Text;
            string courseTitleValue = CourseTitleEntry.Text;
            int courseCreditsValue = Convert.ToInt32(CourseCreditsSlider.Value);
            string courseDepartmentValue = CourseDepartmentEntry.Text;

            if (!string.IsNullOrEmpty(courseIdValue) &&
                !string.IsNullOrEmpty(courseTitleValue) &&
                !string.IsNullOrEmpty(courseDepartmentValue))
            {
                var newCourse = new Course()
                {
                    Id = int.Parse(courseIdValue),
                    Title = courseTitleValue,
                    Credits = courseCreditsValue,
                    Department = courseDepartmentValue,
                };

                string dataFilePath = Path.Combine(FileSystem.CacheDirectory, "CourseListData.json");

                List<Course> courseList = new List<Course>();

                // update existing course list
                if (File.Exists(dataFilePath))
                {
                    string currentDataJson = File.ReadAllText(dataFilePath);
                    courseList = JsonConvert.DeserializeObject<List<Course>>(currentDataJson);
                }

                // update the course object in list
                courseList.First(x => x.Id == newCourse.Id).Title = newCourse.Title;
                courseList.First(x => x.Id == newCourse.Id).Credits = newCourse.Credits;
                courseList.First(x => x.Id == newCourse.Id).Department = newCourse.Department;

                // save course list data
                string courseListJson = JsonConvert.SerializeObject(courseList);
                File.WriteAllText(dataFilePath, courseListJson);

                // remove the previous page
                Page viewPage = this.Navigation.NavigationStack.First(x => x.GetType() == typeof(CourseViewPage));
                this.Navigation.RemovePage(viewPage);
                // jump directly to the CourseListPage
                await this.Navigation.PopAsync();
            }
        }
    }
}