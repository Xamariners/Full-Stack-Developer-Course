﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CourseCreatePage : ContentPage
    {
        public CourseCreatePage()
        {
            InitializeComponent();
        }

        private async void SaveNewCourseButton_Clicked(object sender, EventArgs e)
        {
            string courseIdValue = CourseIdEntry.Text;
            string courseTitleValue = CourseTitleEntry.Text;
            int courseCreditsValue = Convert.ToInt32(CourseCreditsSlider.Value);
            string courseDepartmentValue = CourseDepartmentEntry.Text;

            // 1. Check data validation on new Course data
            if (!string.IsNullOrEmpty(courseIdValue) &&
                !string.IsNullOrEmpty(courseTitleValue) &&
                !string.IsNullOrEmpty(courseDepartmentValue) &&
                int.TryParse(courseIdValue, out int courseIdIntValue))
            {
                Course newCourse = new Course()
                {
                    Id = courseIdIntValue,
                    Title = courseTitleValue,
                    Credits = courseCreditsValue,
                    Department = courseDepartmentValue,
                };

                string dataFilePath = Path.Combine(FileSystem.CacheDirectory, "CourseListData.json");

                List<Course> courseList = new List<Course>();

                // 2. Check if there is previously saved data
                if (File.Exists(dataFilePath))
                {
                    // i. Yes, previously saved data exists
                    // ii. Then load the previously saved data into a list
                    string currentDataJson = File.ReadAllText(dataFilePath);
                    courseList = JsonConvert.DeserializeObject<List<Course>>(currentDataJson);

                    // iii. And append the new Course data into the existing list
                    courseList.Add(newCourse);
                }
                else
                {
                    // i. Nope, no previously saved data exists
                    // ii. Then add the new Course data into a new list
                    courseList.Add(newCourse);
                }

                // 3. Finally save the finalized data into the file
                string courseListJson = JsonConvert.SerializeObject(courseList);
                File.WriteAllText(dataFilePath, courseListJson);

                await this.Navigation.PopAsync();
            }
        }
    }
}