﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CourseListPage : ContentPage
    {
        public CourseListPage()
        {
            InitializeComponent();
        }

        private async void AddNewCourseButton_Clicked(object sender, EventArgs e)
        {
            await this.Navigation.PushAsync(new CourseCreatePage());
        }
    }
}