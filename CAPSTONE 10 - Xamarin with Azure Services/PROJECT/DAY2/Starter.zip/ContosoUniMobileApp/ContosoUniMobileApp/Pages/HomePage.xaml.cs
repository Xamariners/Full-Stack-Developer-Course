﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            // TODO Set up user greeting

            // TODO Get Device Location data
        }

        private string GetGreetingText()
        {
            // TODO
            return null;
        }

        private async Task<Location> GetDeviceLocation()
        {
            // TODO

            return null;
        }

        private async Task SetWeatherData(Location deviceLocation)
        {
            // TODO
        }

        private void SetLocationData(Location deviceLocation)
        {
            // TODO
        }
    }
}