﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class HomePage : ContentPage
    {
        public HomePage()
        {
            InitializeComponent();
        }

        private async void CoursesButton_Clicked(object sender, EventArgs e)
        {
            await this.Navigation.PushAsync(new CourseListPage());
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            UserGreetingTextLabel.Text = GetGreetingText();

            var deviceLocation = await GetDeviceLocation();
            if (deviceLocation != null)
            {
                SetLocationData(deviceLocation);
                await SetWeatherData(deviceLocation);
            }
        }

        private string GetGreetingText()
        {
            if (DateTime.Now.Hour < 12)
            {
                return "Hey there, Good morning!";
            }
            else if (DateTime.Now.Hour < 17)
            {
                return "Hey there, Good afternoon!";
            }
            else
            {
                return "Hey there, Good evening!";
            }
        }

        private async Task<Location> GetDeviceLocation()
        {
            try
            {
                var locationResult = await Geolocation.GetLastKnownLocationAsync();

                return locationResult;
            }
            catch (FeatureNotSupportedException fnsEx)
            {
                // Handle not supported on device exception
            }
            catch (FeatureNotEnabledException fneEx)
            {
                // Handle not enabled on device exception
            }
            catch (PermissionException pEx)
            {
                // Handle permission exception
            }
            catch (Exception ex)
            {
                // Unable to get location
            }

            return null;
        }

        private async Task SetWeatherData(Location deviceLocation)
        {
            try
            {
                var locationDataUrl = $"https://wedra.azurewebsites.net/api/location/search?lattlong={deviceLocation.Latitude},{deviceLocation.Longitude}";
                HttpClient client = new HttpClient();
                string locationDataResult = await client.GetStringAsync(locationDataUrl);
                var locationData = JsonConvert.DeserializeObject<WeatherLocationData>(locationDataResult);

                var locationWeatherDataUrl = $"https://wedra.azurewebsites.net/api/location/{locationData.Woeid}";
                string locationWeatherDataResult = await client.GetStringAsync(locationWeatherDataUrl);
                var locationWeatherData = JsonConvert.DeserializeObject<WeatherData>(locationWeatherDataResult);

                WeatherDataLoadingLabel.Text = $"Weather in {locationData.Title}...";
                WeatherDataDisplayGrid.IsVisible = true;

                // Today Weather
                var weatherStateName = locationWeatherData.ConsolidatedWeather[0].WeatherStateName;
                var weatherTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[0].TheTemp);
                var maxTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[0].MaxTemp);
                var minTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[0].MinTemp);
                TodayNameLabel.Text = "Today";
                TodayWeatherStateNameLabel.Text = $"{weatherStateName} ({weatherTemp}°C)";
                TodayWeatherTemperatureLabel.Text = $"Temp: {minTemp}°C - {maxTemp}°C";

                // Tomorrow Weather
                weatherStateName = locationWeatherData.ConsolidatedWeather[1].WeatherStateName;
                weatherTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[1].TheTemp);
                maxTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[1].MaxTemp);
                minTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[1].MinTemp);
                TomorrowNameLabel.Text = "Tomorrow";
                TomorrowWeatherStateNameLabel.Text = $"{weatherStateName} ({weatherTemp}°C)";
                TomorrowWeatherTemperatureLabel.Text = $"Temp: {minTemp}°C - {maxTemp}°C";

                // Day After Tomorrow Weather
                weatherStateName = locationWeatherData.ConsolidatedWeather[2].WeatherStateName;
                weatherTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[2].TheTemp);
                maxTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[2].MaxTemp);
                minTemp = Math.Floor(locationWeatherData.ConsolidatedWeather[2].MinTemp);
                AfterTomorrowNameLabel.Text = DateTime.Now.ToString("dd MMMM");
                AfterTomorrowWeatherStateNameLabel.Text = $"{weatherStateName} ({weatherTemp}°C)";
                AfterTomorrowWeatherTemperatureLabel.Text = $"Temp: {minTemp}°C - {maxTemp}°C";
            }
            catch (Exception ex)
            {
                // Unable to get location
            }
        }

        private void SetLocationData(Location deviceLocation)
        {
            try
            {
                Location contosoUniLocation = new Location(1.3521, 103.8198);
                double distance = Location.CalculateDistance(
                    deviceLocation, contosoUniLocation,
                    DistanceUnits.Kilometers);

                UserDistanceTextLabel.Text = "You are " + Math.Floor(distance) + " km away from the University!";
            }
            catch (Exception ex)
            {
                // Unable to get location
            }
        }
    }
}