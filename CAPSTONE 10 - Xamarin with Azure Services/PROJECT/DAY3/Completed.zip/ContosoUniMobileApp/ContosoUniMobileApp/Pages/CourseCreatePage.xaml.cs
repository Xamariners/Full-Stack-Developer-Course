﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ContosoUniMobileApp.Models;
using Newtonsoft.Json;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ContosoUniMobileApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class CourseCreatePage : ContentPage
    {
        public CourseCreatePage()
        {
            InitializeComponent();
        }

        private async void SaveNewCourseButton_Clicked(object sender, EventArgs e)
        {
            await this.Navigation.PopAsync();
        }
    }
}